#!/usr/bin/env bash

xattr -lr build/ios/Debug-iphonesimulator/Runner.app/
xattr -cr build/ios/Debug-iphonesimulator/Runner.app/